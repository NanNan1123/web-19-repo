namespace ProductLib;
public enum Category 
{
    None = 0,
    Food = 1,
    Drink = 2,
    Cloth = 4,
    MakeUp = 8,
    Jewelry = 16,
    Vehicle = 32
}